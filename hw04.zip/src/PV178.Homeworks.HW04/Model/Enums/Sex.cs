﻿namespace PV178.Homeworks.HW04.Model.Enums
{
    public enum Sex
    {
        Male, Female, Unknown
    }
}
