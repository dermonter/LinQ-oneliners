﻿namespace PV178.Homeworks.HW04.Model.Enums
{
    public enum AttackSeverenity
    {
        Fatal,
        NonFatal,
        Unknown
    }
}
