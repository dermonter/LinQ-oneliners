﻿namespace PV178.Homeworks.HW04.Model.Enums
{
    public enum GovernmentForm
    {
        Republic, AutonomousRegion, AdministrativeRegion, Monarchy, Territory, FederalRepublic, ParliamentaryDemocracy, Federation, OverseasCommunity
    }
}
