﻿using System;

namespace PV178.Homeworks.HW04
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
